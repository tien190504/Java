
public class bai1 {
    public static void main() {
        System.out.println("Hello!I'm Tien");
        System.out.println("I'm 20 years old");
        System.out.println("This is my first java programming");
    }
}
