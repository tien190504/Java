package bai2;
public class bai2 {
    public static void main() {
        studentbai2 s1 = new studentbai2();
        s1.Input();
        s1.getInfo();
    }
}