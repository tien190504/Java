public class bai7 {
    public static void main() {
        for(int i = 2; i < 10; i++) {
            for(int j = 0; j <= 10; j++) {
                System.out.println(i + " * " + j + " = " + i * j);
            }
            System.out.println("=====================");
        }
    }
}
