/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class testCD {
    public static void main(String[] args) {
        int chon;
        CDCollection dsCD = new CDCollection();
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("1: Them 1 CD");
            System.out.println("2: Xuat danh sach CD");
            System.out.println("3. Xoa CD");
            System.out.println("4. Tim CD theo ma");
            System.out.println("5. So luong CD");
            System.out.println("6. Tong gia thanh CD trong danh sach");
            System.out.println("0. Thoat");
            System.out.println("Moi chon chuc nang: ");
            chon = sc.nextInt();
            switch(chon) {
                case 1:
                    CD cd = new CD();
                    cd.input();
                    dsCD.addCD(cd);
                    break;
                case 2:
                    dsCD.output();
                    break;
                case 3:
                    System.out.println("Nhap cd can xoa");
                    CD cd1 = new CD();
                    cd1.input();
                    dsCD.removeCD(cd1);
                    break;
                case 4: 
                    System.out.println("Nhap ma CD can tim");
                    int findMaCD = sc.nextInt();
                    System.out.println(dsCD.searchCD(findMaCD));
                    break;
                case 5:
                    System.out.println("So luong CD co trong danh sach la " + dsCD.soLuongCD());
                    break;
                case 6:
                    System.out.println("Tong gia thanh CD co trong danh sach " + dsCD.TongGia());
                    break;
                default: chon = 0;
                    break;
            }
        }while(chon != 0);
        sc.close();
    }
}
