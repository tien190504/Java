package bai6;

public class Demo6 {
    public static void main() {
        phuongTrinhbac1 pt1 = new phuongTrinhbac1();
        pt1.input();
        // phuongTrinhbac1 pt1 = new phuongTrinhbac1(6, 9);
        System.out.println("X = " + pt1.giaiPT());
    }
}
