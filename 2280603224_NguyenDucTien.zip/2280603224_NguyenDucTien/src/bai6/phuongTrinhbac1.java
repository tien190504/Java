package bai6;
import java.util.*;
public class phuongTrinhbac1 {
    private int a, b;

    private Scanner sc = new Scanner(System.in);
    //Contructor
    public phuongTrinhbac1() {
        this.a = 0;
        this.b = 0;
    }
    public phuongTrinhbac1(int a, int b) {
        this.a = a;
        this.b = b;
    }
    //Getter and Setter
    public void setA(int a) {
        this.a = a;
    }
    public int getA() {
        return this.a;
    }
    public void setB(int b) {
        this.b = b;
    }
    public int getB() {
        return this.b;
    }

    public void input() {
        System.out.println("Phuong trinh bac nhat: ax + b = 0");
        System.out.print("Nhap a: ");
        this.setA(sc.nextInt());
        System.out.print("Nhap b:");
        this.setB(sc.nextInt());
        
    }
    public double giaiPT() {
        return (double) -this.b / this.a;
    }
    
}
