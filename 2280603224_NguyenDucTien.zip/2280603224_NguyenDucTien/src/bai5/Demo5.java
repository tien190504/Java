package bai5;

public class Demo5 {
    public static void main() {
        Triangle t1 = new Triangle(12, 12, 17);
        Triangle t2 = new Triangle(6, 6, 6);
        Triangle t3 = new Triangle(2, 3, 4);

        System.out.println("Thong so tam giac thu nhat\n" + t1.toString());;
        System.out.println();
        System.out.println("Thong so tam giac thu hai\n" + t2.toString());;
        System.out.println();
        System.out.println("Thong so tam giac thu ba\n" + t3.toString());;
        System.out.println();
        
    }
}
